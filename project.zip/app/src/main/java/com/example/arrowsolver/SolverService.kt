package com.example.arrowsolver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast

class SolverService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var btn: Button? = null
    private var wm: WindowManager? = null
    private var baseRed = -1
    private var lastSig: String? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this)
        b.text = "SOLVE"
        b.setBackgroundColor(Color.parseColor("#FFB300"))
        b.setTextColor(Color.BLACK)
        b.setOnClickListener { toggle() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.y = 80
        wm?.addView(b, lp)
        btn = b
    }

    private fun toggle() {
        running = !running
        btn?.text = if (running) "STOP" else "SOLVE"
        if (running) { baseRed = -1; lastSig = null; step() }
    }

    private fun stop(msg: String) {
        running = false
        btn?.text = "SOLVE"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun grab(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cb(bmp)
            }
            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }

    // ലൈഫ് പോയോ എന്ന് പരിശോധിക്കുക
    private fun livesOk(bmp: Bitmap): Boolean {
        val red = MazeAnalyzer.heartsRed(bmp)
        if (baseRed < 0) baseRed = red
        return !(baseRed > 1000 && red < baseRed * 8 / 10)
    }

    private fun step() {
        if (!running) return
        grab { bmp ->
            if (bmp == null) { stop("screenshot failed"); return@grab }
            if (!livesOk(bmp)) { stop("ലൈഫ് പോയി, നിർത്തി"); return@grab }
            Thread {
                val rounds = MazeAnalyzer.findRounds(bmp)
                handler.post {
                    if (!running) return@post
                    if (rounds.isEmpty()) { stop("തീർന്നു / ടാപ്പ് ചെയ്യാൻ അമ്പ് ഇല്ല"); return@post }
                    val sig = rounds[0].joinToString { "${it.x},${it.y}" }
                    if (sig == lastSig) { stop("മാറ്റം ഇല്ല, നിർത്തി"); return@post }
                    lastSig = sig
                    playRound(rounds, 0)
                }
            }.start()
        }
    }

    private fun playRound(rounds: List<List<Point>>, i: Int) {
        if (!running) return
        if (i >= rounds.size) { handler.postDelayed({ step() }, 800L); return }
        var t = 0L
        for (p in rounds[i]) {
            handler.postDelayed({ if (running) tap(p) }, t)
            t += 70L
        }
        // ഓരോ റൗണ്ടിനും ശേഷം ലൈഫ് പരിശോധിച്ച് മാത്രം അടുത്തതിലേക്ക്
        handler.postDelayed({
            grab { bmp ->
                if (!running) return@grab
                if (bmp != null && !livesOk(bmp)) { stop("ലൈഫ് പോയി, നിർത്തി"); return@grab }
                playRound(rounds, i + 1)
            }
        }, t + 700L)
    }

    private fun tap(p: Point) {
        val path = Path().apply { moveTo(p.x.toFloat(), p.y.toFloat()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        btn?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
