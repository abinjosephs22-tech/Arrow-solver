package com.example.arrowsolver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast

class SolverService : AccessibilityService() {
    // ---- വേഗത ക്രമീകരണം (ലൈഫ് പോകുന്നെങ്കിൽ ROUND_GAP കൂട്ടുക) ----
    private val TAP_GAP = 55L      // ഓരോ ടാപ്പിനും ഇടയിൽ (ms)
    private val ROUND_GAP = 250L   // ഒരു റൗണ്ട് കഴിഞ്ഞ് അടുത്തതിന് മുമ്പ് (ms)
    // ------------------------------------------------------------

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var tapping = false
    private var btn: Button? = null
    private var wm: WindowManager? = null
    private var baseRed = -1
    private var lastSig: String? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this)
        b.text = "SOLVE"
        b.alpha = 0.9f
        b.setBackgroundColor(Color.parseColor("#FFB300"))
        b.setTextColor(Color.BLACK)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val dm = resources.displayMetrics
        lp.x = dm.widthPixels - 320
        lp.y = dm.heightPixels - 380

        // വിരൽ കൊണ്ട് വലിച്ച് നീക്കാം; ചെറുതായി തൊട്ടാൽ SOLVE/STOP
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                        if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm?.updateViewLayout(v, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggle()
                }
                return true
            }
        })
        wm?.addView(b, lp)
        btn = b
    }

    private fun toggle() {
        if (running) { stop("നിർത്തി"); return }
        running = true
        btn?.text = "STOP"
        baseRed = -1; lastSig = null
        step()
    }

    private fun stop(msg: String) {
        running = false
        tapping = false
        handler.removeCallbacksAndMessages(null)
        btn?.text = "SOLVE"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun grab(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cb(bmp)
            }
            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }

    private fun livesOk(bmp: Bitmap): Boolean {
        val red = MazeAnalyzer.heartsRed(bmp)
        if (baseRed < 0) baseRed = red
        return !(baseRed > 1000 && red < baseRed * 8 / 10)
    }

    private fun step() {
        if (!running) return
        grab { bmp ->
            if (!running) return@grab
            if (bmp == null) { stop("screenshot failed"); return@grab }
            if (!livesOk(bmp)) { stop("ലൈഫ് പോയി, നിർത്തി"); return@grab }
            Thread {
                val rounds = MazeAnalyzer.findRounds(bmp)
                handler.post {
                    if (!running) return@post
                    if (rounds.isEmpty()) { stop("തീർന്നു / ടാപ്പ് ചെയ്യാൻ അമ്പ് ഇല്ല"); return@post }
                    val sig = rounds[0].joinToString { "${it.x},${it.y}" }
                    if (sig == lastSig) { stop("മാറ്റം ഇല്ല, നിർത്തി"); return@post }
                    lastSig = sig
                    playAll(rounds)
                }
            }.start()
        }
    }

    // എല്ലാ റൗണ്ടും ഇടയ്ക്ക് നിർത്താതെ ടാപ്പ് ചെയ്യും; ലൈഫ് പരിശോധന സമാന്തരമായി നടക്കും
    private fun playAll(rounds: List<List<Point>>) {
        var t = 0L
        tapping = true
        for (round in rounds) {
            for (p in round) {
                handler.postDelayed({ if (running) tap(p) }, t)
                t += TAP_GAP
            }
            t += ROUND_GAP
        }
        monitor()
        handler.postDelayed({ tapping = false; step() }, t + 900L)
    }

    private fun monitor() {
        if (!running || !tapping) return
        grab { bmp ->
            if (!running || !tapping) return@grab
            if (bmp != null && !livesOk(bmp)) { stop("ലൈഫ് പോയി, നിർത്തി"); return@grab }
            handler.postDelayed({ monitor() }, 350L)
        }
    }

    private fun tap(p: Point) {
        val path = Path().apply { moveTo(p.x.toFloat(), p.y.toFloat()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 20)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        btn?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
