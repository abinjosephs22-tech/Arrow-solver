package com.example.arrowsolver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.Toast

class SolverService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var btn: Button? = null
    private var wm: WindowManager? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this)
        b.text = "SOLVE"
        b.setBackgroundColor(Color.parseColor("#FFB300"))
        b.setTextColor(Color.BLACK)
        b.setOnClickListener { toggle() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.y = 80
        wm?.addView(b, lp)
        btn = b
    }

    private fun toggle() {
        running = !running
        btn?.text = if (running) "STOP" else "SOLVE"
        if (running) step()
    }

    private fun stop(msg: String) {
        running = false
        btn?.text = "SOLVE"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun step() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp == null) { stop("screenshot error"); return }
                Thread {
                    val rounds = MazeAnalyzer.findRounds(bmp)
                    handler.post { runRounds(rounds) }
                }.start()
            }
            override fun onFailure(errorCode: Int) { stop("screenshot failed: $errorCode") }
        })
    }

    private fun runRounds(rounds: List<List<Point>>) {
        if (!running) return
        if (rounds.isEmpty()) { stop("തീർന്നു / ടാപ്പ് ചെയ്യാൻ അമ്പ് ഇല്ല"); return }
        var t = 0L
        for (round in rounds) {
            for (p in round) {
                handler.postDelayed({ if (running) tap(p) }, t)
                t += 70L
            }
            t += 350L   // അമ്പുകൾ പോകാൻ ചെറിയ കാത്തിരിപ്പ്
        }
        handler.postDelayed({ step() }, t + 1000L)  // ബാക്കി ഉണ്ടോ എന്ന് പരിശോധിക്കാൻ
    }

    private fun tap(p: Point) {
        val path = Path().apply { moveTo(p.x.toFloat(), p.y.toFloat()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        btn?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
