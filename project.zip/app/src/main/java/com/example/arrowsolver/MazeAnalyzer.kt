package com.example.arrowsolver

import android.graphics.Bitmap
import android.graphics.Point

data class TapEvent(val x: Int, val y: Int, val t: Long)

object MazeAnalyzer {
    // നേവി നിറമുള്ള വരകൾ (ടെക്സ്റ്റ്/ഐക്കണുകൾ ഒഴിവാക്കാൻ)
    private fun isInk(c: Int): Boolean {
        val r = (c shr 16) and 255
        val b = c and 255
        return b - r > 25 && r < 90 && b < 150
    }

    private fun run(lab: IntArray, w: Int, h: Int, label: Int, cx: Int, cy: Int, dx: Int, dy: Int): Int {
        var best = 0
        for (o in -1..1) {
            var x = cx + o * dy
            var y = cy + o * dx
            var k = 0
            while (x in 0 until w && y in 0 until h && lab[y * w + x] == label) { k++; x += dx; y += dy }
            if (k > best) best = k
        }
        return best
    }

    // ഹൃദയങ്ങളിലെ ചുവപ്പ് പിക്സൽ എണ്ണം (ലൈഫ് പോയോ എന്ന് അറിയാൻ)
    fun heartsRed(bmp: Bitmap): Int {
        val w = bmp.width; val h = bmp.height
        val x0 = (w * 0.35).toInt(); val x1 = (w * 0.65).toInt()
        val y0 = (h * 0.095).toInt(); val y1 = (h * 0.14).toInt()
        val rw = x1 - x0; val rh = y1 - y0
        val px = IntArray(rw * rh)
        bmp.getPixels(px, 0, rw, x0, y0, rw, rh)
        var c = 0
        for (p in px) {
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (r > 200 && g < 110 && b < 110) c++
        }
        return c
    }

    // ത്രികോണ (അമ്പിന്റെ തല) template: ഏത് ദിശയിലാണ് ഏറ്റവും നന്നായി ചേരുന്നത് എന്ന് സ്കോർ
    private fun triScore(lab: IntArray, w: Int, h: Int, label: Int, cx: Int, cy: Int,
                         dx: Int, dy: Int, hh: Int, out: IntArray): Float {
        val px = -dy; val py = dx
        var best = -1f
        for (t in -(hh * 8 / 10)..(hh / 5)) for (u in -2..2) {
            var tot = 0; var hit = 0
            for (a in 0 until hh) {
                val hw = (hh - a) / 2
                for (b in -hw..hw) {
                    val sp = t + a
                    val x = cx + dx * sp + px * (b + u)
                    val y = cy + dy * sp + py * (b + u)
                    tot++
                    if (x in 0 until w && y in 0 until h && lab[y * w + x] == label) hit++
                }
            }
            val sc = hit.toFloat() / tot
            if (sc > best) { best = sc; out[0] = t; out[1] = u }
        }
        return best
    }

    // ഒരു അമ്പിന്റെ പിക്സലുകളിലൂടെ BFS; എത്ര പിക്സൽ സന്ദർശിച്ചു എന്ന് തിരികെ നൽകും (അവസാനം സന്ദർശിച്ചത് ഏറ്റവും ദൂരെ)
    private fun bfs(lab: IntArray, w: Int, h: Int, src: Int, label: Int, d: IntArray, queue: IntArray): Int {
        var qh = 0; var qt = 0
        queue[qt++] = src; d[src] = 0
        while (qh < qt) {
            val p = queue[qh++]
            val x = p % w; val y = p / w
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val nx = x + dx; val ny = y + dy
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val q = ny * w + nx
                if (lab[q] == label && d[q] < 0) { d[q] = d[p] + 1; queue[qt++] = q }
            }
        }
        return qt
    }

    // മുഴുവൻ screenshot-ൽ നിന്ന് മേസ് ഉള്ള ഭാഗം മാത്രം മുറിച്ചെടുത്ത് വിശകലനം (വേഗത കൂട്ടാൻ)
    fun findSchedule(full: Bitmap, speed: Float, tapGap: Long, margin: Long): List<TapEvent> {
        val w = full.width; val h = full.height
        val px = IntArray(w * h)
        full.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (isInk(px[row + x])) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                    if (y < y0) y0 = y
                    y1 = y
                }
            }
        }
        if (x1 < 0) return emptyList()
        val m = 8
        x0 = Math.max(0, x0 - m); y0 = Math.max(0, y0 - m)
        x1 = Math.min(w - 1, x1 + m); y1 = Math.min(h - 1, y1 + m)
        val crop = Bitmap.createBitmap(full, x0, y0, x1 - x0 + 1, y1 - y0 + 1)
        val res = analyze(crop, speed, tapGap, margin)
        return res.map { TapEvent(it.x + x0, it.y + y0, it.t) }
    }

    private fun analyze(bmp: Bitmap, speed: Float, tapGap: Long, margin: Long): List<TapEvent> {
        val w = bmp.width; val h = bmp.height; val n = w * h
        val px = IntArray(n)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val ink = BooleanArray(n) { isInk(px[it]) }

        // 1) വരയുടെ കനം (ഏറ്റവും കൂടുതൽ വരുന്ന run നീളം)
        val hist = IntArray(41)
        for (y in 0 until h) {
            var run = 0
            for (x in 0..w) {
                if (x < w && ink[y * w + x]) run++ else { if (run in 2..40) hist[run]++; run = 0 }
            }
        }
        var sw = 2
        for (i in 2..40) if (hist[i] > hist[sw]) sw = i

        // 2) connected components = ഓരോ അമ്പും
        val lab = IntArray(n)
        val stack = IntArray(n)
        var cnt = 0
        for (s in 0 until n) {
            if (!ink[s] || lab[s] != 0) continue
            cnt++
            var sp = 0
            stack[sp++] = s; lab[s] = cnt
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (ink[q] && lab[q] == 0) { lab[q] = cnt; stack[sp++] = q }
                }
            }
        }

        // 3) അമ്പിന്റെ തല = വരയേക്കാൾ തടിച്ച ഭാഗം (integral image)
        val iw = w + 1
        val integ = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                if (ink[y * w + x]) row++
                integ[(y + 1) * iw + x + 1] = integ[y * iw + x + 1] + row
            }
        }
        val r = Math.max(2, Math.round(sw * 0.75f))
        val s = 2 * r + 1
        val coreIdx = IntArray(cnt + 1)
        val coreCnt = LongArray(cnt + 1); val sx = LongArray(cnt + 1); val sy = LongArray(cnt + 1)
        for (y in r until h - r) for (x in r until w - r) {
            if (!ink[y * w + x]) continue
            val sum = integ[(y + r + 1) * iw + x + r + 1] - integ[(y - r) * iw + x + r + 1] -
                integ[(y + r + 1) * iw + x - r] + integ[(y - r) * iw + x - r]
            if (sum * 10 >= s * s * 9) {
                val l = lab[y * w + x]
                coreCnt[l]++; sx[l] += x.toLong(); sy[l] += y.toLong(); coreIdx[l] = y * w + x
            }
        }
        val isArrow = BooleanArray(cnt + 1) { coreCnt[it] >= 2 }
        var bx0 = w; var by0 = h; var bx1 = 0; var by1 = 0
        for (i in 0 until n) {
            if (lab[i] != 0 && isArrow[lab[i]]) {
                val x = i % w; val y = i / w
                if (x < bx0) bx0 = x; if (x > bx1) bx1 = x
                if (y < by0) by0 = y; if (y > by1) by1 = y
            }
        }

        // 3.5) ഓരോ അമ്പിന്റെയും വാൽ (tail) മുതലുള്ള ദൂരം dT (വഴിയിലൂടെ) കണക്കാക്കുക
        val dA = IntArray(n) { -1 }
        val dT = IntArray(n) { -1 }
        val queue = IntArray(n)
        for (l in 1..cnt) {
            if (!isArrow[l]) continue
            val c1 = bfs(lab, w, h, coreIdx[l], l, dA, queue)
            val far = queue[c1 - 1]
            for (i in 0 until c1) dA[queue[i]] = -1
            bfs(lab, w, h, far, l, dT, queue)
        }

        // 4) ഓരോ അമ്പിന്റെയും ദിശ (തലയുടെ ആകൃതി വച്ച്), മുന്നിലുള്ള തടസ്സങ്ങളും അവ മാറാൻ വേണ്ട ദൂരവും
        val half = Math.max(1, sw / 2)
        val h1 = Math.max(6, Math.round(sw * 2.8f))
        val h2 = Math.max(7, Math.round(sw * 3.5f))
        val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        val arrows = ArrayList<Int>()
        val uncertain = HashSet<Int>()
        val centers = HashMap<Int, Point>()
        val blockers = HashMap<Int, HashMap<Int, Int>>()
        val tmp = IntArray(2)
        for (l in 1..cnt) {
            if (!isArrow[l]) continue
            val cx = (sx[l] / coreCnt[l]).toInt()
            val cy = (sy[l] / coreCnt[l]).toInt()
            var bestSc = -1f
            var bdx = 1; var bdy = 0; var bt = 0; var bu = 0; var bH = h1
            for (hh in intArrayOf(h1, h2)) for (d in dirs) {
                val sc = triScore(lab, w, h, l, cx, cy, d[0], d[1], hh, tmp)
                if (sc > bestSc) { bestSc = sc; bdx = d[0]; bdy = d[1]; bt = tmp[0]; bu = tmp[1]; bH = hh }
            }
            arrows.add(l)
            centers[l] = Point(cx, cy)
            if (bestSc < 0.6f) uncertain.add(l)
            val px = -bdy; val py = bdx
            val sApex = bt + bH - 1
            var sp = sApex - 3
            while (sp < sApex + 6) {
                val s2 = sp + 1
                var ok = false
                for (o in -1..1) {
                    val x = cx + bdx * s2 + px * (bu + o)
                    val y = cy + bdy * s2 + py * (bu + o)
                    if (x in 0 until w && y in 0 until h && lab[y * w + x] == l) ok = true
                }
                if (!ok) break
                sp = s2
            }
            // blocker label -> അതിന്റെ വാൽ മുതൽ ഏറ്റവും ദൂരെയുള്ള തടസ്സ പിക്സലിലേക്കുള്ള ദൂരം
            val hits = HashMap<Int, Int>()
            var k = sp + 2
            while (true) {
                val x = cx + bdx * k + px * bu
                val y = cy + bdy * k + py * bu
                if (x < bx0 || x > bx1 || y < by0 || y > by1) break
                for (o in -half..half) {
                    val xx = x + px * o; val yy = y + py * o
                    if (xx in 0 until w && yy in 0 until h) {
                        val idx = yy * w + xx
                        val q = lab[idx]
                        if (q != 0) {
                            val dd = if (isArrow[q]) dT[idx] else Int.MAX_VALUE
                            val old = hits[q]
                            if (old == null || dd > old) hits[q] = dd
                        }
                    }
                }
                k++
            }
            blockers[l] = hits
        }

        // 5) simulation: ഓരോ അമ്പും ഏത് സമയത്ത് ടാപ്പ് ചെയ്യണം
        val tapT = HashMap<Int, Long>()
        val remaining = HashSet<Int>(arrows)
        val events = ArrayList<TapEvent>()
        var cursor = 0L
        while (remaining.isNotEmpty()) {
            var bestL = -1
            var bestR = Long.MAX_VALUE
            for (l in remaining) {
                if (l in uncertain) continue
                var ok = true
                var r = 0L
                for ((a, dist) in blockers[l]!!) {
                    if (a == l || !isArrow[a] || a in remaining || dist == Int.MAX_VALUE) { ok = false; break }
                    val rr = tapT[a]!! + (Math.max(dist, 0) * 1000f / speed).toLong() + margin
                    if (rr > r) r = rr
                }
                if (ok && r < bestR) { bestR = r; bestL = l }
            }
            if (bestL < 0) break
            val t = Math.max(bestR, cursor)
            tapT[bestL] = t
            cursor = t + tapGap
            val c = centers[bestL]!!
            events.add(TapEvent(c.x, c.y, t))
            remaining.remove(bestL)
        }
        return events
    }
}
