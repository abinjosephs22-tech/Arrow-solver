package com.example.arrowsolver

import android.graphics.Bitmap
import android.graphics.Point

object MazeAnalyzer {
    // നേവി നിറമുള്ള വരകൾ (ടെക്സ്റ്റ്/ഐക്കണുകൾ ഒഴിവാക്കാൻ)
    private fun isInk(c: Int): Boolean {
        val r = (c shr 16) and 255
        val b = c and 255
        return b - r > 25 && r < 90 && b < 150
    }

    private fun run(lab: IntArray, w: Int, h: Int, label: Int, cx: Int, cy: Int, dx: Int, dy: Int): Int {
        var best = 0
        for (o in -1..1) {
            var x = cx + o * dy
            var y = cy + o * dx
            var k = 0
            while (x in 0 until w && y in 0 until h && lab[y * w + x] == label) { k++; x += dx; y += dy }
            if (k > best) best = k
        }
        return best
    }

    fun findRounds(bmp: Bitmap): List<List<Point>> {
        val w = bmp.width; val h = bmp.height; val n = w * h
        val px = IntArray(n)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val ink = BooleanArray(n) { isInk(px[it]) }

        // 1) വരയുടെ കനം (ഏറ്റവും കൂടുതൽ വരുന്ന run നീളം)
        val hist = IntArray(41)
        for (y in 0 until h) {
            var run = 0
            for (x in 0..w) {
                if (x < w && ink[y * w + x]) run++ else { if (run in 2..40) hist[run]++; run = 0 }
            }
        }
        var sw = 2
        for (i in 2..40) if (hist[i] > hist[sw]) sw = i

        // 2) connected components = ഓരോ അമ്പും
        val lab = IntArray(n)
        val stack = IntArray(n)
        var cnt = 0
        for (s in 0 until n) {
            if (!ink[s] || lab[s] != 0) continue
            cnt++
            var sp = 0
            stack[sp++] = s; lab[s] = cnt
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (ink[q] && lab[q] == 0) { lab[q] = cnt; stack[sp++] = q }
                }
            }
        }

        // 3) അമ്പിന്റെ തല = വരയേക്കാൾ തടിച്ച ഭാഗം (integral image)
        val iw = w + 1
        val integ = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                if (ink[y * w + x]) row++
                integ[(y + 1) * iw + x + 1] = integ[y * iw + x + 1] + row
            }
        }
        val r = Math.max(2, Math.round(sw * 0.75f))
        val s = 2 * r + 1
        val coreCnt = LongArray(cnt + 1); val sx = LongArray(cnt + 1); val sy = LongArray(cnt + 1)
        for (y in r until h - r) for (x in r until w - r) {
            if (!ink[y * w + x]) continue
            val sum = integ[(y + r + 1) * iw + x + r + 1] - integ[(y - r) * iw + x + r + 1] -
                integ[(y + r + 1) * iw + x - r] + integ[(y - r) * iw + x - r]
            if (sum * 10 >= s * s * 9) {
                val l = lab[y * w + x]
                coreCnt[l]++; sx[l] += x.toLong(); sy[l] += y.toLong()
            }
        }
        val isArrow = BooleanArray(cnt + 1) { coreCnt[it] >= 2 }
        var bx0 = w; var by0 = h; var bx1 = 0; var by1 = 0
        for (i in 0 until n) {
            if (lab[i] != 0 && isArrow[lab[i]]) {
                val x = i % w; val y = i / w
                if (x < bx0) bx0 = x; if (x > bx1) bx1 = x
                if (y < by0) by0 = y; if (y > by1) by1 = y
            }
        }

        // 4) ഓരോ അമ്പിന്റെയും ദിശ, മുന്നിലുള്ള തടസ്സങ്ങൾ (blockers)
        val half = Math.max(1, sw / 2)
        val arrows = ArrayList<Int>()
        val centers = HashMap<Int, Point>()
        val blockers = HashMap<Int, HashSet<Int>>()
        for (l in 1..cnt) {
            if (!isArrow[l]) continue
            val cx = (sx[l] / coreCnt[l]).toInt()
            val cy = (sy[l] / coreCnt[l]).toInt()
            val left = run(lab, w, h, l, cx, cy, -1, 0)
            val right = run(lab, w, h, l, cx, cy, 1, 0)
            val up = run(lab, w, h, l, cx, cy, 0, -1)
            val down = run(lab, w, h, l, cx, cy, 0, 1)
            val dx: Int; val dy: Int; val tip: Int
            if (Math.abs(left - right) >= Math.abs(up - down)) {
                if (left < right) { dx = -1; dy = 0; tip = left } else { dx = 1; dy = 0; tip = right }
            } else {
                if (up < down) { dx = 0; dy = -1; tip = up } else { dx = 0; dy = 1; tip = down }
            }
            val set = HashSet<Int>()
            var k = tip + 2
            while (true) {
                val x = cx + dx * k; val y = cy + dy * k
                if (x < bx0 || x > bx1 || y < by0 || y > by1) break
                for (o in -half..half) {
                    val xx = x + o * dy; val yy = y + o * dx
                    if (xx in 0 until w && yy in 0 until h) {
                        val q = lab[yy * w + xx]
                        if (q != 0) set.add(q)
                    }
                }
                k++
            }
            arrows.add(l)
            centers[l] = Point(cx, cy)
            blockers[l] = set
        }

        // 5) simulation: ഏത് അമ്പ് ആദ്യം, ഏതൊക്കെ ഒരുമിച്ച് എന്ന് കണക്കാക്കുക
        val remaining = HashSet<Int>(arrows)
        val rounds = ArrayList<List<Point>>()
        while (remaining.isNotEmpty()) {
            val ready = remaining.filter { l ->
                blockers[l]!!.all { b -> isArrow[b] && b != l && b !in remaining }
            }
            if (ready.isEmpty()) break
            rounds.add(ready.map { centers[it]!! })
            remaining.removeAll(ready.toSet())
        }
        return rounds
    }
}
